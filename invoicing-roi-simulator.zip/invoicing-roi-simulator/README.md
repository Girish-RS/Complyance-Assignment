# Invoicing ROI Simulator

A simple web app that helps businesses calculate ROI and payback when switching from manual to automated invoicing.

## 🚀 Features
- Instant ROI and savings simulation
- Local database for saved scenarios
- PDF report generation (optional)
- Simple UI built with Bootstrap

## 🧱 Stack
- Backend: Flask (Python)
- Frontend: HTML + Bootstrap
- Database: SQLite
- Hosting: Render / Local

## ⚙️ Setup Instructions

### 1. Clone or Download
```bash
git clone https://github.com/YOUR_USERNAME/invoicing-roi-simulator.git
cd invoicing-roi-simulator
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Run locally
```bash
python app.py
```
Visit → http://127.0.0.1:5000

### 4. Deploy on Render
1. Push this repo to GitHub
2. Go to [Render.com](https://render.com)
3. Create new Web Service
4. Set:
   - **Build command:** `pip install -r requirements.txt`
   - **Start command:** `python app.py`
5. Deploy and get your live link!

